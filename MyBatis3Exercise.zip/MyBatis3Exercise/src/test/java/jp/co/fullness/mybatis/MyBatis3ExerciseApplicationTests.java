package jp.co.fullness.mybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBatis3ExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}

package jp.co.fullness.mybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBatis3ExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBatis3ExerciseApplication.class, args);
	}

}
